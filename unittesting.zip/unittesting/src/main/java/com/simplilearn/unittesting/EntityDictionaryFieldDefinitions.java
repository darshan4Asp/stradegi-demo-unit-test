package com.simplilearn.unittesting;

public class EntityDictionaryFieldDefinitions {

	private String dataLabel;
	private String fieldName;
	private String fieldCode;
	private String dataType;
	private String helpDescription;
	private boolean isPredefined;
	private boolean digitSegregation;
	private boolean isSysField;
	private boolean isUsed;
	private boolean isValidUpto;
	private boolean isMultiSelect;
	private boolean isEnforceableField;
	private int length;
	private int precision;
	private Dropdowns dropdowns = null;

	public String getDataLabel() {
		return dataLabel;
	}

	public void setDataLabel(String dataLabel) {
		this.dataLabel = dataLabel;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getFieldCode() {
		return fieldCode;
	}

	public void setFieldCode(String fieldCode) {
		this.fieldCode = fieldCode;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public String getHelpDescription() {
		return helpDescription;
	}

	public void setHelpDescription(String helpDescription) {
		this.helpDescription = helpDescription;
	}

	public boolean isPredefined() {
		return isPredefined;
	}

	public void setPredefined(boolean isPredefined) {
		this.isPredefined = isPredefined;
	}

	public boolean isDigitSegregation() {
		return digitSegregation;
	}

	public void setDigitSegregation(boolean digitSegregation) {
		this.digitSegregation = digitSegregation;
	}

	public boolean isSysField() {
		return isSysField;
	}

	public void setSysField(boolean isSysField) {
		this.isSysField = isSysField;
	}

	public boolean isUsed() {
		return isUsed;
	}

	public void setUsed(boolean isUsed) {
		this.isUsed = isUsed;
	}

	public boolean isValidUpto() {
		return isValidUpto;
	}

	public void setValidUpto(boolean isValidUpto) {
		this.isValidUpto = isValidUpto;
	}

	public boolean isMultiSelect() {
		return isMultiSelect;
	}

	public void setMultiSelect(boolean isMultiSelect) {
		this.isMultiSelect = isMultiSelect;
	}

	public boolean isEnforceableField() {
		return isEnforceableField;
	}

	public void setEnforceableField(boolean isEnforceableField) {
		this.isEnforceableField = isEnforceableField;
	}

	public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public int getPrecision() {
		return precision;
	}

	public void setPrecision(int precision) {
		this.precision = precision;
	}

	public Dropdowns getDropdowns() {
		return dropdowns;
	}

	public void setDropdowns(Dropdowns dropdowns) {
		this.dropdowns = dropdowns;
	}

}
